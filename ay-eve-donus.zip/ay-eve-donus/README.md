# AY — Eve Dönüş

2D-Pixel-Art-Plattformer, läuft komplett im Browser (HTML5 Canvas, Vanilla JavaScript).
Keine Engine, keine Abhängigkeiten, keine externen Dateien.

## Starten
- Lokal: `index.html` in Chrome/Edge öffnen.
- Online: GitHub Pages (Settings → Pages → Branch `main`).
- Handy: im Querformat spielen.

## Steuerung
- Bewegen: A/D oder Pfeiltasten (Touch: ◀ ▶)
- Springen: Leertaste (Touch: ▲)
- Schlagen: J oder Mausklick (Touch: SCHLAG)
- Interagieren: E (Touch: AKTION)
- Pause: Esc
